import os
import sys
from pathlib import Path
from dotenv import load_dotenv
from agents.agent_framework import AutonomousAgent

load_dotenv()

class SystemArchitectAgent(AutonomousAgent):
    """
    Agent responsible for system architecture, refactoring, and core implementation.
    """
    
    def __init__(self) -> None:
        super().__init__(
            name="System Architect",
            role="Lead Developer & Architect",
            capabilities=["refactor", "audit", "implement", "design"]
        )
        
    def execute_task(self, task: dict) -> None:
        """
        Execute a development task.
        
        :param task: A dictionary containing task details with keys 'title', 'description', etc.
        """
        self.log(f"🏗️ System Architect starting task: {task['title']}")
        
        # 1. Analyze the Request
        analysis = self.think(
            f"I need to execute this task: {task['title']}\nDescription: {task.get('description', '')}\n\nHow should I approach this?", 
            system_prompt="You are a System Architect. Plan the implementation steps."
        )
        self.log(f"🤔 Analysis: {analysis}")
        
        # 2. Perform the work
        if "audit" in task['title'].lower():
            self.perform_audit()
        elif task.get('type') in ['implement', 'restore'] or "implement" in task['title'].lower() or "restore" in task['title'].lower():
            self.implement_feature(task)
        else:
            self.log("⚠️ Generic task execution not fully implemented yet.")

    def implement_feature(self, task: dict) -> None:
        """
        Implement a feature based on the task description.
        
        :param task: A dictionary containing task details with keys 'title', 'description', etc.
        """
        self.log(f"🛠️ Implementing feature: {task['title']}")
        
        # 1. Plan the implementation
        plan = self.think(
            f"Plan the implementation for: {task['title']}\nDescription: {task.get('description', '')}\n\nReturn a JSON list of files to create/edit with their content. This is a Python MUD project. Use Python code.",
            system_prompt="You are a System Architect for a Python MUD. Output JSON: { 'files': [ { 'path': str, 'content': str, 'description': str } ] }",
            response_format={"type": "json_object"}
        )
        
        files = plan.get('files', [])
        self.log(f"📋 Plan involves {len(files)} files.")
        
        # 2. Apply changes
        for file in files:
            path = file['path']
            content = file['content']
            desc = file['description']
            
            self.log(f"📝 Writing {path}: {desc}")
            
            # Ensure directory exists
            os.makedirs(os.path.dirname(path), exist_ok=True)
            
            with open(path, 'w') as f:
                f.write(content)
                
        self.log(f"✅ Implementation of {task['title']} complete.")
        self.commit_work(task['id'], f"Implement {task['title']}")

if __name__ == '__main__':
    agent = SystemArchitectAgent()
    # Simulate task
    agent.execute_task({"id": "story-1.1", "title": "Complete OO Transition Audit", "description": "Audit root files"})