# Agent System Requirements

Install required package:
```bash
pip install openai
```

Already in requirements.txt, but if not installed:
```bash
pip install -r requirements.txt
```
